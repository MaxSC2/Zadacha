# ООП Модуль 1 — Больница

Состав пакета:
- Otchet_OOP_M1_Bolnica.docx / .pdf — отчёт
- UML_klassov.png / .svg — диаграмма классов
- UML_istochnik.puml / .drawio — исходники UML
- Matrica_trassirovki.xlsx — матрица трассировки
- Audit_rubrika.md — аудит по рубрике
- CHANGELOG.md
