# FILE MAP

## PRIMARY SOURCES

### 01_ASSIGNMENT/ООП модуль1 2026.pdf
ROLE: PRIMARY REQUIREMENTS
PRIORITY: 1
Use for the exact wording of the Module 1 assignment.

### 02_SOURCE_MATERIALS/02_CURRENT_REPORT/ООП_Модуль_1_Отчет_Больница_ИСУ-24-1 (1) — копия.docx
ROLE: CURRENT EDITABLE DRAFT
PRIORITY: 3
Use as a draft and source of existing work.
Not authoritative for implementation.

### 02_SOURCE_MATERIALS/02_CURRENT_REPORT/ООП_Модуль_1_Отчет_Больница_ИСУ-24-1 (1).pdf
ROLE: CURRENT REPORT PDF / VISUAL REFERENCE
PRIORITY: 4
Use to inspect current layout/content.
Not authoritative for implementation.

### 02_SOURCE_MATERIALS/04_PROJECT_SOURCE/
ROLE: IMPLEMENTATION SOURCE OF TRUTH
PRIORITY: 2
Use actual Python source to determine real classes, attributes, methods and behavior.

## REFERENCES

### 02_SOURCE_MATERIALS/03_EXAMPLES/Пример 1.pdf
ROLE: REFERENCE ONLY
PRIORITY: 5
Use for presentation logic, specificity and demonstration ideas.
Do not copy visual design literally.
Do not derive requirements from it.

### 02_SOURCE_MATERIALS/03_EXAMPLES/Пример 2.pdf
ROLE: REFERENCE ONLY
PRIORITY: 5
Use for presentation logic and model-to-implementation explanation.
Do not derive requirements from it.

## OPTIONAL

### 03_OPTIONAL_HUMANIZER/Humanizer_MAX_2.0.md
ROLE: OPTIONAL STYLE PASS
Run only after content/model/UML/code are frozen.
Never allow it to modify facts or architecture.

## MISSING MATERIAL

Lecture 1 referenced by the assignment is not currently included.
If supplied later, give it priority over generic knowledge for lecture-specific terminology.
