# PROJECT TASK — OOP Module 1 — Hospital

## Identity

Discipline: Объектно-ориентированное программирование
Module: 1

Topic:
«Объектная модель учёта пациентов и медицинских приёмов в больнице»

Students:
Бахтагареев М.Р.
Добош Н.А.

Group: ИСУ-24-1

Reviewer: Астапенко Н.В.

City/Year: Петропавловск, 2026

## Original assignment requirements

From the supplied assignment:

1. Determine the main objects of the selected domain.
2. For each object determine properties.
3. Determine methods/actions performed by the objects.
4. Build a class diagram showing objects and relationships.
5. Use Association, Aggregation, Composition and Generalization where appropriate.
6. Explain why those relationship types were selected.
7. Submit a report containing the diagram and a brief description of classes and relationships.
8. Answer the three self-check questions.

Do not claim the assignment itself requires an exact number of classes or relationships unless the source explicitly says so.

## Domain scope

The model is limited to:

registration of a patient
→ medical record/card
→ appointment with a doctor
→ medical appointment
→ diagnosis/prescription
→ patient history.

Organizational structure:

hospital
→ departments
→ medical staff
→ doctors/nurses.

Do not turn this into a full hospital information system.

## Current implementation baseline

The current project contains these classes as the starting baseline:

Person
Patient
MedicalStaff
Doctor
Nurse
Hospital
Department
MedicalCard
Appointment

Verify before freezing the final model.

## Current expected responsibilities to audit

Person:
common person data.

Patient:
patient data, medical card, appointments/history.

MedicalStaff:
common staff data/interface.

Doctor:
doctor-specific data, appointments, appointment handling.

Nurse:
nurse-specific data and nurse actions.

Hospital:
hospital data, departments, searching/statistics where actually implemented.

Department:
department data and attached staff.

MedicalCard:
patient medical history/records.

Appointment:
scheduled medical interaction and its state/result.

## Current relationship baseline to verify

Generalization:
- Person → Patient
- Person → MedicalStaff
- MedicalStaff → Doctor
- MedicalStaff → Nurse

Composition:
- Hospital → Department
- Patient → MedicalCard

Aggregation:
- Department → MedicalStaff

Association:
- Patient → Appointment
- Doctor → Appointment
- MedicalCard → Appointment

This is only a starting hypothesis. Verify every relationship from the source materials and code.

## Forbidden UML

Dependency = forbidden.

Do not use:
- Dependency;
- <<use>>;
- dashed dependency arrows.

Only use Association, Aggregation, Composition and Generalization.

## Real implementation checks

Review the actual project source and verify especially:

- Patient appointment cancellation.
- Patient history retrieval.
- Nurse room preparation and patient escorting.
- Hospital doctor search.
- Hospital statistics.
- Doctor appointment list.
- MedicalCard history.
- Appointment description.
- Appointment prescription storage.
- Appointment state validation.
- Actual polymorphic get_info().
- Actual main.py demonstration path.

Do not copy a previous report's method table without checking code.

## Scenario goal

Use the real implementation to construct one coherent scenario:

Hospital creation
→ Department creation
→ staff creation
→ staff attachment to department
→ polymorphic staff output
→ patient creation
→ medical card creation
→ appointment creation
→ nurse action where appropriate
→ doctor conducts appointment
→ result/history update
→ rescheduling/cancellation where relevant
→ history/search/statistics demonstration.

Group these into a readable scenario instead of creating a section for every line of code.

## UML page goal

One main class diagram.

Prefer an A4 landscape page for the diagram if necessary.

Use three visual zones:

1. Person hierarchy.
2. Hospital/Department organization.
3. Medical process around Appointment and MedicalCard.

Show:
- class names;
- relevant attributes;
- key methods;
- relationship types;
- required multiplicities.

Do not overload the diagram with technical noise.

Legend:
△ Generalization
◆ Composition
◇ Aggregation
— Association

Dependency must not appear.

## Report structure target

Recommended:

Title page
Contents

1. Introduction
1.1 Purpose
1.2 Tasks

2. Domain analysis
2.1 Scope and concrete process
2.2 Main objects/classes
2.3 Attributes and methods
2.4 Inheritance hierarchy

3. Object model
3.1 Class diagram
3.2 Relationships
3.3 Justification of relationship types
3.4 Multiplicities
3.5 Scenario

4. Python implementation
4.1 Base classes and inheritance
4.2 Polymorphism
4.3 Composition and aggregation
4.4 Associations
4.5 Demonstration

5. Self-check questions

6. Conclusion

Adapt structure if the source assignment or supplied examples justify a better arrangement.

Do not inflate the report with unrelated theory.

## Formatting target

From the supplied rubric:
- Times New Roman;
- 14 pt;
- single spacing;
- justified text;
- first-line indent 1.25 cm;
- title page;
- contents;
- figure captions;
- unified formatting;
- readable UML.

The UML page may be landscape if necessary.

## Content/rubric target

Rubric totals 100:
1. Domain analysis — 10
2. Class definition — 5
3. Class properties — 5
4. Class methods — 5
5. Relationships — 20
6. UML quality — 5
7. Class/model description — 25
8. Formatting — 15
9. Independence/AI check — 10

For self-audit, target >=95/100 on content/format consistency.

Do not promise any AI-detector percentage. The rubric states the allowed detector threshold is <=20%; do not game the detector.
