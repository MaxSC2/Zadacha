# EXECUTION MAP

## Phase 0 — Read

Read all source materials and project files.
Do not edit anything.

## Phase 1 — Requirements Audit

Extract:
- assignment requirements;
- rubric;
- formatting rules;
- UML restrictions;
- required deliverables.

Output: REQUIREMENTS_AUDIT.

## Phase 2 — Implementation Audit

Inspect every source file in the project.
Determine:
- classes;
- inheritance;
- attributes;
- methods;
- behaviors;
- actual demo flow.

Output: IMPLEMENTATION_AUDIT.

## Phase 3 — Current Report Audit

Compare current report with real implementation.

Output:
- claims supported by code;
- claims unsupported by code;
- missing implemented elements;
- stale/incorrect fragments.

## Phase 4 — Gap Analysis

Classify findings:
MATCH / GAP / CONFLICT / EXCESS / RISK.

## Phase 5 — Model Reconciliation

Freeze a defensible domain model.
Avoid unnecessary expansion.

## Phase 6 — Freeze Classes

For each class freeze:
- purpose;
- attributes;
- methods;
- parent/children.

## Phase 7 — Freeze Relationships

For each relationship freeze:
- type;
- multiplicity;
- role;
- justification;
- code evidence.

Enforce:
DEPENDENCY COUNT = 0.

## Phase 8 — UML Specification

Create textual diagram specification first.

## Phase 9 — UML Construction

Build one-page readable class diagram.
Prefer landscape A4 for the UML page.

## Phase 10 — UML Validation

Check:
- all needed classes;
- correct arrows/diamonds;
- multiplicities;
- no ambiguous lines;
- no dependency.

## Phase 11 — Code Validation

Run the real project if the environment allows.
Check demo output.

## Phase 12 — Scenario Validation

Map the written scenario to actual execution.

## Phase 13 — Report Writing

Create the report only after model/code/UML are stable.

## Phase 14 — Humanizer

Optional.
Use only for language quality after facts are locked.

## Phase 15 — Document Generation

Generate DOCX/PDF and image assets.

## Phase 16 — Visual QA

Inspect every page.
Fix:
- awkward page breaks;
- unreadable tables;
- tiny UML;
- overflowing code;
- inconsistent captions;
- empty pages;
- incorrect TOC.

## Phase 17 — Independent Audit

Pretend you are a strict grader seeing the work for the first time.
Do not praise it.
Find defects.

Final output must include the defects found and how they were resolved.
