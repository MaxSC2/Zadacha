# START COMMANDS FOR GLM

## START 1 — AUDIT ONLY

Apply MASTER_INSTRUCTION and PROJECT_TASK.

Read every attached file and the entire project source.

Do NOT create or rewrite the final report.
Do NOT create the final UML.
Do NOT modify project files yet.

Perform:
1. Requirements Audit.
2. Implementation Audit.
3. Current Report Audit.
4. Example Analysis.
5. Gap Analysis.
6. Initial Traceability Matrix.

Special checks:
- actual classes;
- actual attributes;
- actual methods;
- actual demo flow;
- current report mismatches;
- UML relationship types;
- multiplicities;
- Dependency count.

Return only the audit and recommended correction order.

## START 2 — RECONCILE MODEL

Continue from the audit.

Freeze the final domain model.
Do not write the final report yet.

Return:
- final classes;
- attributes;
- methods;
- inheritance;
- relationships;
- multiplicities;
- scenario;
- unresolved issues.

## START 3 — UML

Create the UML specification and graphical diagram.

One page.
Readable.
Only four relationship types.
Dependency = 0.

Validate the diagram before proceeding.

## START 4 — IMPLEMENTATION

Validate the model against the real Python project.
Make only minimal required code corrections.
Do not add unrelated functionality.

## START 5 — REPORT

Create the complete report using the frozen model.

Use the current report as a draft, not as truth.
Use examples as references only.

## START 6 — HUMANIZER

Apply Humanizer MAX 2.0 only to the finalized report text.

Preserve all technical facts, class names, method names, UML relations, multiplicities and requirements.

Do not intentionally introduce errors.

## START 7 — FINAL QA

Act as an independent grader.
Score the work against the exact rubric.
Find all defects.
Then fix them and regenerate the final document.

Do not optimize for a numeric AI detector result.
