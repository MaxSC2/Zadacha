# EXPECTED OUTPUT

## Required

1. Final DOCX report.
2. Final PDF report for visual QA.
3. UML PNG.
4. UML SVG.
5. Editable UML source (PlantUML/draw.io/etc.).
6. Requirements/model traceability matrix.
7. Final audit against rubric.
8. Change log from the original draft.

## Final report should contain

- title page;
- contents;
- clear goal/tasks;
- concrete domain boundaries;
- classes and responsibilities;
- attributes/methods;
- inheritance hierarchy;
- one-page UML;
- relationship table with types and multiplicities;
- justification for each important relationship;
- one coherent execution scenario;
- selected Python fragments that prove the model;
- three self-check answers;
- conclusion.

## Quality invariants

DEPENDENCY COUNT = 0.

UML ↔ CODE ↔ REPORT = consistent.

No unsupported claims.
No unfinished sections.
UML readable on one page.
Formatting compliant with rubric.

## Important

The original assignment itself only requires the core object/domain/UML/report tasks. Do not inflate the document with unrelated application features merely because they exist in the project.
